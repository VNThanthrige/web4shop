from django.contrib import admin
from .models import category
from .models import Unit
from .models import item
from .models import supplier
from .models import order
from .models import Employee

# Register your models here.
admin.site.register(category)
admin.site.register(Unit) 
admin.site.register(item)
admin.site.register(supplier)
admin.site.register(order)
admin.site.register(Employee)


