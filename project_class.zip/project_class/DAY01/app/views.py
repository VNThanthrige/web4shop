from django.shortcuts import render
from .models import Employee, category, Unit, item, supplier, order
from .forms import EmployeeForm, TestForm, categoryForm, UnitForm, ItemForm, orderForm, supplierForm
from django.core.paginator import Paginator
from .filters import *

# Create your views here.
def category_view(request):
    page_number = request.GET.get('page')
    filter = CategoryFilter(request.GET, queryset=category.objects.all())
    categories = filter.qs
    paginator = Paginator(categories, 3)
    Page = paginator.get_page(page_number)
    
    if request.method == 'POST':
        form = categoryForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = categoryForm()
    context = {'form': form, 'page':Page}
    return render(request, 'Category.html', context)

def unit_view(request):
    units = Unit.objects.all()
    if request.method == 'POST':
        form = UnitForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = UnitForm()
    context = {'form': form, 'uts': units}
    return render(request, 'unit.html', context)

def test_view(request):
    if request.method == 'POST':
        form = TestForm(request.POST)
        if form.is_valid():
            # Handle the form processing here if needed
            pass
    else:
        form = TestForm()
    context = {'form': form}
    return render(request, 'test.html', context)

def item_view(request):
    page_number = request.GET.get('page')
    filter = ItemFilter(request.GET, queryset=item.objects.all())
    items = filter.qs
    paginator = Paginator(items, 3)
    Page = paginator.get_page(page_number)
    
    if request.method == 'POST':
        form = ItemForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = ItemForm()
    context = {'form': form, 'page':Page}
    return render(request, 'Item.html', context)

def supplier_view(request):
    suppliers = supplier.objects.all()
    if request.method == 'POST':
        form = supplierForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = supplierForm()
    context = {'form': form, 'supplrs': suppliers}
    return render(request, 'supplier.html', context)

def order_view(request):
    orders = order.objects.all()
    if request.method == 'POST':
        form = orderForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = orderForm()
    context = {'form': form, 'ordrs': orders}
    return render(request, 'order.html', context)

def employee_view(request):
    employees = Employee.objects.all()
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = EmployeeForm()
    context = {'form': form, 'Employs': employees}
    return render(request, 'Employee.html', context)
