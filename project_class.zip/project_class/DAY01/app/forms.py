from django import forms 
from .models import category,Unit,item,supplier,order,Employee


class TestForm(forms.Form):
    name = forms.CharField()
    
class categoryForm(forms.ModelForm):
    class Meta:
        model = category
        fields = '__all__'
        
class UnitForm(forms.ModelForm):
    class Meta:
        model = Unit
        fields = '__all__'
        
class ItemForm(forms.ModelForm):
    class Meta:
        model = item
        fields = '__all__'
        
class supplierForm(forms.ModelForm):
    class Meta:
        model = supplier
        fields = '__all__'
        
class orderForm(forms.ModelForm):
    class Meta:
        model = order
        fields = '__all__'
        
class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = '__all__'